<img src="https://github.com/perispectus/stackdoku/blob/main/icon_1.png?raw=true" align="left" width="80" height="80">

# Stackdoku
A 3D Sudoku-like puzzle game

* Author: *Ryan 'perispectus' Lelache*
* Version: *v0.1.0*
* Release Date: *18 Jan 2022*

## What is Stackdoku?
*Stackdoku* is a casual Sudoku-like puzzle game developed in Godot 3.4. It was developed as an initial game project to test out the features of Godot's 3D engine and learn somewhat more advanced concepts for game development after building mostly in Twine.